# para renomear, vá pelo cmd do win e digite rename *.s *.data

def execute_bmp2oac2(frames):
    archive = open('script.bat', 'w')

    for i in range(frames):
        languages = ['no', 'jp', 'pt']
        
        for language in languages:
            tmp = f'bmp2oac2.exe {language}{str(i).rjust(5, "0")}' + '\n'
            archive.write(tmp)

    archive.close()

def include_sprites(frames, prefix=''):
    archive = open('frames.s', 'w')

    for i in range(frames):
        languages = ['no', 'jp', 'pt']

        index = str(i).rjust(5, '0')

        for language in languages:
            tmp = f'f{language}{index}: .string "{prefix}{language}{index}.bin"' + '\n'
            archive.write(tmp)

    archive.close()

frames = 5216

execute_bmp2oac2(frames)
include_sprites(frames, prefix='frames/')
